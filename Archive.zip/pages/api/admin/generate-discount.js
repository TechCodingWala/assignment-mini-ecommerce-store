const { adminGenerateDiscount } = require('../../../lib/store')

export default function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'method_not_allowed' })
  const result = adminGenerateDiscount()
  if (!result.success) return res.status(400).json({ error: result.reason, detail: result })
  res.json(result)
}
