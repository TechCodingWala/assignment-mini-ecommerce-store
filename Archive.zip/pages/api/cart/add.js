const { addToCart, getCart } = require('../../../lib/store')

export default function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'method_not_allowed' })
  const { userId, item } = req.body
  if (!userId || !item || !item.itemId || !item.price) return res.status(400).json({ error: 'invalid_payload' })
  const cart = addToCart(userId, item)
  res.json({ success: true, cart })
}
