const { checkout, getCart } = require('../../../lib/store')

export default function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'method_not_allowed' })
  const { userId, couponCode } = req.body
  if (!userId) return res.status(400).json({ error: 'userId_required' })
  const cart = getCart(userId)
  if (!cart || cart.items.length === 0) return res.status(400).json({ error: 'empty_cart' })
  const result = checkout(userId, couponCode)
  if (!result.success) return res.status(400).json({ error: result.reason, detail: result.detail })
  res.json(result)
}
