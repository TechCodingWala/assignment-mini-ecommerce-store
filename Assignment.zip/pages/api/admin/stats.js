const { adminStats } = require('../../../lib/store')

export default function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'method_not_allowed' })
  res.json(adminStats())
}
