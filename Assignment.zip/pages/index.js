import { useState, useEffect } from 'react'

const PRODUCTS = [
  { itemId: 'p1', name: 'T-Shirt', price: 20 },
  { itemId: 'p2', name: 'Mug', price: 10 },
  { itemId: 'p3', name: 'Sticker Pack', price: 5 }
]

export default function Home() {
  const [userId] = useState('user-1')
  const [cart, setCart] = useState({ items: [] })
  const [coupon, setCoupon] = useState('')
  const [message, setMessage] = useState(null)

  useEffect(() => { fetchCart() }, [])

  async function fetchCart() {
    // no read endpoint; we use internal route via add responses.
    // This app will maintain cart locally by fetching admin stats or after actions.
  }

  async function add(item) {
    const res = await fetch('/api/cart/add', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ userId, item }) })
    const data = await res.json()
    if (data.success) setCart(data.cart)
  }

  async function checkout() {
    const res = await fetch('/api/cart/checkout', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ userId, couponCode: coupon || undefined }) })
    const data = await res.json()
    if (!res.ok) {
      setMessage({ type: 'danger', text: data.error || 'checkout_failed' })
      return
    }
    if (data.generatedCoupon) {
      setMessage({ type: 'success', text: `Order placed. You received coupon ${data.generatedCoupon.code}` })
    } else {
      setMessage({ type: 'success', text: `Order placed. Total: ₹${data.order.total}` })
    }
    setCart({ items: [] })
    setCoupon('')
  }

  const subtotal = cart.items.reduce((s, it) => s + (it.price * it.quantity), 0)

  return (
    <div className="container py-4">
      <h1 className="mb-4">Mini Ecommerce Store</h1>
      {message && <div className={`alert alert-${message.type}`}>{message.text}</div>}
      <div className="row">
        <div className="col-md-6">
          <h4>Products</h4>
          <ul className="list-group">
            {PRODUCTS.map(p => (
              <li key={p.itemId} className="list-group-item d-flex justify-content-between align-items-center">
                <div>
                  <strong>{p.name}</strong>
                  <div className="text-muted">₹{p.price}</div>
                </div>
                <button className="btn btn-sm btn-primary" onClick={() => add({ ...p, quantity: 1 })}>Add</button>
              </li>
            ))}
          </ul>
        </div>
        <div className="col-md-6">
          <h4>Cart</h4>
          <ul className="list-group mb-2">
            {cart.items.length === 0 && <li className="list-group-item">Cart is empty</li>}
            {cart.items.map(it => (
              <li key={it.itemId} className="list-group-item d-flex justify-content-between align-items-center">
                <div>{it.name} x {it.quantity}</div>
                <div>₹{it.price * it.quantity}</div>
              </li>
            ))}
          </ul>
          <div className="mb-2">Subtotal: <strong>₹{subtotal}</strong></div>
          <div className="mb-2">
            <input className="form-control" placeholder="Discount code" value={coupon} onChange={e => setCoupon(e.target.value)} />
          </div>
          <button className="btn btn-success" onClick={checkout}>Checkout</button>
        </div>
      </div>
    </div>
  )
}
