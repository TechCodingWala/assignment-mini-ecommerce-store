const store = require('../lib/store')

describe('store logic', () => {
  beforeEach(() => {
    // reset internal store
    store._internal.carts = {}
    store._internal.orders = []
    store._internal.coupons = []
    store._internal.orderCount = 0
  })

  test('add to cart and checkout without coupon', () => {
    store.addToCart('u1', { itemId: 'i1', name: 'Test', price: 100, quantity: 1 })
    const c = store.getCart('u1')
    expect(c.items.length).toBe(1)
    const res = store.checkout('u1')
    expect(res.success).toBe(true)
    expect(res.order.total).toBe(100)
    expect(store._internal.orderCount).toBe(1)
  })

  test('coupon generation on nth order', () => {
    process.env.ORDER_N = '2'
    // first order
    store.addToCart('u1', { itemId: 'i1', name: 'A', price: 10, quantity: 1 })
    store.checkout('u1')
    // second order should generate coupon
    store.addToCart('u2', { itemId: 'i2', name: 'B', price: 20, quantity: 1 })
    const res = store.checkout('u2')
    expect(res.generatedCoupon).not.toBeNull()
  })

  test('apply coupon reduces total and marks used', () => {
    // create coupon
    const coupon = store._internal.coupons[0] || store._internal.coupons.push({ code: 'TEST', percent: 10, used: false }) && store._internal.coupons[0]
    store.addToCart('u3', { itemId: 'i3', name: 'C', price: 50, quantity: 1 })
    const res = store.checkout('u3', 'TEST')
    if (!res.success) throw new Error('checkout failed in test: ' + JSON.stringify(res))
    expect(res.order.total).toBe(45)
    const couponObj = store._internal.coupons.find(c => c.code === 'TEST')
    expect(couponObj.used).toBe(true)
  })
})
